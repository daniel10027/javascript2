function one()
 {
 	var nom1 = propmpt("Entrez le nom du joueur 1");
 	var num1 = parseInt(prompt("Donner un nombre"));
 	return num1;
 }
function two()
 {
 	var nom2 = propmpt("Entrez le nom du joueur 2");
 	var num2 = parseInt(prompt("Donner un nombre"));
 	return num2;
 }
var joueur1 = one ();
console.log(joueur1);
var joueur2 = two ();
console.log(joueur2);

if (joueur1 > joueur2){
	document.getElementbyId(result).innerHTML += "Le joueur1 remporte la partie à " +joueur1+ "contre" +joueur2;
}

if (joueur1 < joueur2){
	document.getElementbyId(result).innerHTML += "Le joueur2 remporte la partie à " +joueur2+ "contre" +joueur1;
}

else {
	document.getElementbyId(result).innerHTML += "Égalité"
}

